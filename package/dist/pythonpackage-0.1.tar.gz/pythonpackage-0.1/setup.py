from setuptools import setup
setup(name = "pythonpackage",
version='0.1',
description="This is easy to use module",
Long_description="This module makes your code simple and easy.This module makes your code faster",
author="Someone",
package=['pythonpackage'],
install_requires=[])